<?php
include("template/header.php")
?>

<br><br>
  <div class="container">
    <h1>Welkom bij rijschool DriveSmart!</h1>
    <p>AL wil je ribba dit is sws de plek</p>
  </div>

</form>


<?php
include("template/footer.php");
?>