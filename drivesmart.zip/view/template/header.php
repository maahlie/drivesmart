<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="view\css\styles.css">
    </head>
<body>
    <nav class="top-nav">
        <a href="/drivesmart">Home</a>
        <a href="contact">Contact</a>
        <a href="login" id="login-nav">Inloggen</a>
    </nav>