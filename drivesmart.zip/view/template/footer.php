<footer class="footer">
  <p>Drivesmart 2024</p>
</footer>
</body>

<script src="view\js\validation.js"></script>

</html>